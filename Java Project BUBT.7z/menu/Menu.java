package menu;

public class Menu {
	public Menu(){}
	
	public void options() {
		System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
		System.out.println("\n						 1. Order");
		System.out.println("					   	 2. Show Order Details");
		System.out.println("						 3. Pay Bill");
		System.out.println("						 4. Distribute Products");
		System.out.println("						 5. Log out");	
	}
}
