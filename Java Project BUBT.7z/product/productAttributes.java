package product;

public interface productAttributes {
	public String getBrand();
	public String getModel();
	public double getPrice();
	public String getType();
	public String getOrderDate();
	public abstract void showInfo();
	
}
